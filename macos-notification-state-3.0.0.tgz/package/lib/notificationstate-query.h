int queryUserSessionState();
